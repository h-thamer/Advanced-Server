from django.shortcuts import get_object_or_404, redirect
from django.views.generic import ListView
from django.views.generic.base import View
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.messages.views import SuccessMessageMixin
from django.utils import timezone
from django.contrib import messages

from .forms import CustomerForm, ParcelForm
from .models import Customer, Parcel


class HomeView(LoginRequiredMixin, ListView):
    template_name = "index.html"
    queryset = Parcel.objects.all()


class RegisterView(SuccessMessageMixin, CreateView):
    template_name = "accounts/registration.html"
    form_class = UserCreationForm
    success_url = "/login"
    success_message = "Account Created. You can login now."


class CustomerListView(ListView):
    template_name = "customer_list.html"
    queryset = Customer.objects.all()


class CustomerCreateView(LoginRequiredMixin, SuccessMessageMixin, CreateView):
    template_name = "customer_create.html"
    form_class = CustomerForm
    success_url = "/customers"
    success_message = "Customer Created Successfully"


class CustomerUpdateView(LoginRequiredMixin, SuccessMessageMixin, UpdateView):
    template_name = "customer_update.html"
    form_class = CustomerForm
    success_url = "/customers"
    success_message = "Customer Updated Successfully"
    queryset = Customer.objects.all()


class CustomerDeleteView(LoginRequiredMixin, DeleteView):
    template_name = "customer_delete_confirm.html"
    queryset = Customer.objects.all()
    success_url = "/customers"


class ParcelCreateView(LoginRequiredMixin, SuccessMessageMixin, CreateView):
    template_name = "parcel_create.html"
    form_class = ParcelForm
    success_url = "/"
    success_message = "Parcel Created Successfully"


class ParcelDetailView(LoginRequiredMixin, DetailView):
    template_name = "parcel_detail.html"
    queryset = Parcel.objects.all()


class ParcelUpdateView(LoginRequiredMixin, SuccessMessageMixin, UpdateView):
    template_name = "parcel_update.html"
    form_class = ParcelForm
    queryset = Parcel.objects.all()
    success_url = "/"
    success_message = "Parcel Updated Successfully"


class ParcelDeleteView(LoginRequiredMixin, DeleteView):
    template_name = "parcel_delete_confirm.html"
    queryset = Parcel.objects.all()
    success_url = "/"


class ParcelStatusUpdateView(LoginRequiredMixin, View):
    def get(self, request, *args, **kwargs):
        parcel = get_object_or_404(Parcel, pk=kwargs.get('pk'))
        status = request.GET.get('status')

        if not parcel.customer:
            messages.error(request, 'Please assign a customer first')
            return redirect('/')

        if status == 'delivered':
            parcel.is_delivered = True
            parcel.delivered_at = timezone.now()

        elif status == 'collected':
            parcel.is_collected = True
            parcel.collected_at = timezone.now()

        parcel.save()
        messages.success(request, 'Status Updated Successfully')
        return redirect('/')
