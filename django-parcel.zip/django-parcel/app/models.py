from django.db import models


class Customer(models.Model):
    first_name = models.CharField(max_length=20)
    last_name = models.CharField(max_length=20)
    email = models.EmailField(max_length=30)
    phone_number = models.CharField(max_length=20)
    address = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class Parcel(models.Model):
    uid = models.CharField(max_length=20, unique=True)
    dimensions = models.CharField(max_length=50)
    weight = models.CharField(max_length=20)
    customer = models.ForeignKey(
        Customer, on_delete=models.CASCADE, related_name="parcels", blank=True, null=True)
    is_collected = models.BooleanField(default=False)
    is_delivered = models.BooleanField(default=False)
    collected_at = models.DateTimeField(blank=True, null=True)
    delivered_at = models.DateTimeField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.uid
