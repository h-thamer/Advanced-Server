from django import forms
from django.contrib.auth.models import User
from .models import Customer, Parcel


class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = "__all__"


class ParcelForm(forms.ModelForm):
    class Meta:
        model = Parcel
        fields = ['uid', 'dimensions', 'weight', 'customer']
