from django.urls import path
from django.contrib.auth import views as auth_views

from . import views

urlpatterns = [
    path('', views.HomeView.as_view(), name="home"),
    path('login/', auth_views.LoginView.as_view(template_name="accounts/login.html"), name="login"),
    path('register/', views.RegisterView.as_view(), name="register"),
    path('logout/', auth_views.LogoutView.as_view(), name="logout"),
    path('parcel/create/', views.ParcelCreateView.as_view(),
         name="parcel_create"),
    path('parcel/<int:pk>/',
         views.ParcelDetailView.as_view(), name="parcel_detail"),
    path('parcel/<int:pk>/update/',
         views.ParcelUpdateView.as_view(), name="parcel_update"),
    path('parcel/<int:pk>/delete/',
         views.ParcelDeleteView.as_view(), name="parcel_delete"),
    path('parcel/<int:pk>/status/',
         views.ParcelStatusUpdateView.as_view(), name="parcel_status"),
    path('customers/', views.CustomerListView.as_view(), name="customers"),
    path('customers/create/', views.CustomerCreateView.as_view(),
         name="customer_create"),
    path('customers/<int:pk>/edit/', views.CustomerUpdateView.as_view(),
         name="customer_update"),
    path('customers/<int:pk>/delete/', views.CustomerDeleteView.as_view(),
         name="customer_delete"),
]
